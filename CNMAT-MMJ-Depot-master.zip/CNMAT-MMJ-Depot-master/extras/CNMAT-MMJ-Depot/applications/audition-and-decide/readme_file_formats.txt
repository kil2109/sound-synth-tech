Note about file formats:

If you would like to use Excel to edit your files for AAD I or II, use the 
"audition_decide_II_admin.xls" file, by opening up in Excel, hitting "select all", 
and then pasting into either a blank text file, 
or into a coll editor window, 
then using that as your file to load in from disk.