This folder contains abstractions that have been made obsolete by new object functions in Max 5.  They are being maintained for pedagogical value, and because older patches may depend on them. Please avoid using these in new patches.

Michael Zbyszynski
31 December 2008